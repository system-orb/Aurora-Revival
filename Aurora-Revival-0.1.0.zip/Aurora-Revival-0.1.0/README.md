# Aurora Revival 0.1.0

A KDE Plasma 6 concept theme inspired by the early glass UI of Windows Longhorn Build 4074.
Target: Arch Linux, Plasma 6, Wayland, 1920x1080, Kvantum.

This is an original community theme concept. It is not affiliated with Microsoft.
It does not include Microsoft-owned icons, fonts, wallpapers, or other proprietary assets.

## Included

- Plasma 6 Global Theme package: `global/look-and-feel/com.aurorarevival.longhorn4074`
- Plasma Style: `plasma/desktoptheme/AuroraRevival`
- Aurorae window decoration: `aurorae/Aurora4074`
- KDE color scheme: `colors/AuroraRevival.colors`
- Kvantum theme starter (palette/config prototype): `kvantum/AuroraRevival`
- Original 1920x1080 SVG wallpaper: `wallpaper/AuroraRevival-4074.svg`
- User-local install and uninstall scripts.

## Install (Arch Linux / Plasma 6)

From the extracted directory:

```bash
chmod +x install.sh uninstall.sh
./install.sh
```

The installer copies assets into your user directories only. It does not use sudo,
overwrite system files, change your current desktop layout, or automatically switch
your active theme.

## Apply the components

1. **Colors:** System Settings → Colors & Themes → Colors → `Aurora Revival`.
2. **Plasma Style:** System Settings → Colors & Themes → Plasma Style → `Aurora Revival`.
3. **Window decoration:** System Settings → Colors & Themes → Window Decorations → `Aurora 4074`.
4. **Kvantum (optional):** install `kvantum` from the Arch repositories, open Kvantum Manager,
   select `AuroraRevival`, then Apply. Some Qt apps may need restarting.
6. **Wallpaper:** the installer copies it to `~/Pictures/AuroraRevival/` (or your XDG Pictures directory).
   Right-click desktop → Configure Desktop and Wallpaper → select `AuroraRevival-4074.svg`.

## Glass / blur

On Wayland, KWin compositing is always active. In System Settings → Workspace Behavior →
Desktop Effects, enable **Blur** if available. The Aurorae theme includes a blur mask;
actual blur strength and availability depend on the KWin version, GPU driver, and compositor.

The panel SVG is translucent, but a full Longhorn-style Sidebar/Dock and custom animated
widgets are not included in this first visual foundation release.

## Uninstall

```bash
./uninstall.sh
```

This removes only the exact Aurora Revival directories/files installed by this package.
It does not delete user configuration files or restore previous theme selections.

## Known limitations of 0.1.0

- The Plasma Style is intentionally a small SVG overlay and falls back to Breeze for
  unprovided assets.
- Kvantum is currently a palette/config prototype; its full widget SVG mapping is not complete.
- No custom icon theme or Sidebar plasmoid yet.
- Global Theme is packaged for discoverability, but install does not auto-apply it.
- Test on a spare user account first if you want to experiment with global appearance.

## Project layout

See `docs/INSTALL-ARCH.md` and `docs/DESIGN.md`.
