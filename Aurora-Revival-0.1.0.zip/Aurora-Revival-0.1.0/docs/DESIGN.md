# Design brief

Aurora Revival is an original interpretation of the Longhorn 4074 visual language:
cool blue glass, cyan edge highlights, deep navy surfaces, soft radial light and
compact early-futurist controls.

Palette:
- Deep navy: `#071C35`
- Glass blue: `#4B91B8`
- Ice highlight: `#A9E6F8`
- Jade accent: `#65BDAA`
- Text: `#F0F7FC`

The first release prioritizes a coherent visual base over a risky all-at-once desktop
layout replacement. Sidebar, taskbar layout, icons, and custom widgets are planned for
later iterations.
