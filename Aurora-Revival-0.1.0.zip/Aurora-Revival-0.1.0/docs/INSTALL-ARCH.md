# Arch Linux installation notes

## Recommended packages

```bash
sudo pacman -S --needed plasma-workspace plasma-desktop kwin kf6-kconfig \
  kvantum qt6ct
```

Package names can differ slightly depending on your Arch installation and enabled
repositories. `kvantum` is optional if you only want the KDE-native theme pieces.

## Install

```bash
unzip Aurora-Revival-0.1.0.zip
cd Aurora-Revival-0.1.0
./install.sh
```

## Apply in System Settings

Apply the color scheme, Plasma Style, and Aurorae decoration separately. This avoids
forcing a new panel layout onto an existing Plasma desktop.

For Qt applications, select the Kvantum style in System Settings → Colors & Themes →
Application Style (or configure the Qt platform theme used by your setup), then select
the AuroraRevival theme in Kvantum Manager.

## Wayland notes

- Log out and back in if a component does not appear after installation.
- Restart Plasma Shell only if needed; avoid killing the whole session.
- Blur requires KWin's Blur desktop effect and compatible graphics drivers.
- SVG wallpaper can be selected directly by Plasma; rasterizing is not required.

## Safe rollback

The uninstall script removes only:
- `~/.local/share/color-schemes/AuroraRevival.colors`
- `~/.local/share/plasma/desktoptheme/AuroraRevival`
- `~/.local/share/plasma/look-and-feel/com.aurorarevival.longhorn4074`
- `~/.local/share/aurorae/themes/Aurora4074`
- `~/.config/Kvantum/AuroraRevival`

It does not modify `kdeglobals`, `kwinrc`, or your panel layout.
