#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DATA="${XDG_DATA_HOME:-$HOME/.local/share}"
CONFIG="${XDG_CONFIG_HOME:-$HOME/.config}"
PICTURES="${XDG_PICTURES_DIR:-$HOME/Pictures}"

install -d "$DATA/color-schemes" \
  "$DATA/plasma/desktoptheme" \
  "$DATA/plasma/look-and-feel" \
  "$DATA/aurorae/themes" \
  "$CONFIG/Kvantum" \
  "$PICTURES/AuroraRevival"

cp -a "$ROOT/colors/AuroraRevival.colors" "$DATA/color-schemes/"
cp -a "$ROOT/plasma/desktoptheme/AuroraRevival" "$DATA/plasma/desktoptheme/"
cp -a "$ROOT/global/look-and-feel/com.aurorarevival.longhorn4074" "$DATA/plasma/look-and-feel/"
cp -a "$ROOT/aurorae/Aurora4074" "$DATA/aurorae/themes/"
cp -a "$ROOT/kvantum/AuroraRevival" "$CONFIG/Kvantum/"
cp -a "$ROOT/wallpaper/AuroraRevival-4074.svg" "$PICTURES/AuroraRevival/"

printf '\nAurora Revival 0.1.0 installed for the current user.\n'
printf 'No system files or existing KDE settings were changed.\n'
printf 'Wallpaper copied to: %s/AuroraRevival/\n\n' "$PICTURES"
printf 'Next: open System Settings and select the color scheme, Plasma Style,\n'
printf 'and Aurorae window decoration separately. See README.md for details.\n'
