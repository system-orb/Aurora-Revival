#!/usr/bin/env bash
set -euo pipefail

DATA="${XDG_DATA_HOME:-$HOME/.local/share}"
CONFIG="${XDG_CONFIG_HOME:-$HOME/.config}"
PICTURES="${XDG_PICTURES_DIR:-$HOME/Pictures}"

rm -f "$DATA/color-schemes/AuroraRevival.colors"
rm -rf "$DATA/plasma/desktoptheme/AuroraRevival"
rm -rf "$DATA/plasma/look-and-feel/com.aurorarevival.longhorn4074"
rm -rf "$DATA/aurorae/themes/Aurora4074"
rm -rf "$CONFIG/Kvantum/AuroraRevival"
rm -f "$PICTURES/AuroraRevival/AuroraRevival-4074.svg"
rmdir "$PICTURES/AuroraRevival" 2>/dev/null || true

printf 'Aurora Revival files removed from user theme directories.\n'
printf 'Your active KDE settings and panel layout were not modified.\n'
